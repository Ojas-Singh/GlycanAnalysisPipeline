Warning:

Some Glycan residues in the CHARMM naming format have residue names longer than the maximum four characters that are permitted in the PDB format. Therefore, it can be difficult to differentiate between similar residues (i.e. Glc and GlcNAc) on their residue name alone.